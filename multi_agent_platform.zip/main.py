from agents.planner import Planner
from agents.executor import Executor
from agents.critic import Critic

def main():
    task = "Analyze a dataset and generate insights"

    planner = Planner()
    executor = Executor()
    critic = Critic()

    plan = planner.plan(task)
    result = executor.execute(plan)
    feedback = critic.review(result)

    print("Task:", task)
    print("Plan:", plan)
    print("Result:", result)
    print("Feedback:", feedback)

if __name__ == "__main__":
    main()
