class Executor:
    def execute(self, plan):
        return f"Executed plan: {plan}"
