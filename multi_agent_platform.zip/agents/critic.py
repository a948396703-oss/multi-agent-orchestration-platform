class Critic:
    def review(self, result):
        return f"Review OK. Minor improvements suggested for: {result}"
