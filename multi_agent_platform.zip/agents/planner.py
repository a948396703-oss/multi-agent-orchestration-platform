class Planner:
    def plan(self, task):
        return f"Step1: Understand task -> Step2: Execute -> Step3: Summarize ({task})"
