# Multi-Agent Orchestration Platform

A simple multi-agent system with Planner, Executor, and Critic.

## Features
- Task decomposition
- Multi-agent collaboration
- Simple feedback loop

## Run
```bash
pip install -r requirements.txt
python main.py
```
